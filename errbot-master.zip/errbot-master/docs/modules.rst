errbot
======

.. toctree::
   :maxdepth: 4

   errbot
