pytest_plugins = ["errbot.backends.test"]
