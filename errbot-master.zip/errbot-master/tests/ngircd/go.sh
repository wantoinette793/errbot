ngircd --config ./ngircd.conf -n
