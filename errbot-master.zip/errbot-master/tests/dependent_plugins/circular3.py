from errbot import BotPlugin


class Circular3(BotPlugin):
    pass
