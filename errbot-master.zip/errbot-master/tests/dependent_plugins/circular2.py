from errbot import BotPlugin


class Circular2(BotPlugin):
    pass
