from errbot import BotPlugin


class Chained2(BotPlugin):
    pass
