from errbot import BotPlugin


class Circular4(BotPlugin):
    pass
