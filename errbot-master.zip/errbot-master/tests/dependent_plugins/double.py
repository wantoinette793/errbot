from errbot import BotPlugin


class Double(BotPlugin):
    pass
