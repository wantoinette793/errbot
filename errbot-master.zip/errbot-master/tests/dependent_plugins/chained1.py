from errbot import BotPlugin


class Chained1(BotPlugin):
    pass
