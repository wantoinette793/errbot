from errbot import BotPlugin


class Circular1(BotPlugin):
    pass
