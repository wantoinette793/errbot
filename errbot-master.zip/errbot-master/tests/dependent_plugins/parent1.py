from errbot import BotPlugin


class Parent1(BotPlugin):
    def shared_function(self):
        return "youpi"
