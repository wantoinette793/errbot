from errbot import BotPlugin


class Chained3(BotPlugin):
    pass
