from errbot import BotPlugin


class Parent2(BotPlugin):
    pass
