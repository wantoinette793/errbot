import logging

logging.getLogger("").setLevel(logging.INFO)
