from errbot import BotPlugin


class PluginB(BotPlugin):
    pass
