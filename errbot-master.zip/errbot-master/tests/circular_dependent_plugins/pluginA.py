from errbot import BotPlugin


class PluginA(BotPlugin):
    pass
