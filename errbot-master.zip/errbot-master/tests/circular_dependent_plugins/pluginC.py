from errbot import BotPlugin


class PluginC(BotPlugin):
    pass
