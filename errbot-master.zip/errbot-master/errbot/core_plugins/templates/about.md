This is Errbot version {{version}}

* Visit http://errbot.io/ for more information about errbot in general.
* Visit http://errbot.io/en/latest/#user-guide for help with configuration,
  administration and plugin development.

Errbot is built through the hard work and dedication of everyone who
contributes code, documentation and bug reports at https://github.com/errbotio
but a special thank you should be given to Guillaume Binet, Tali Petrover,
Ben van Daele, Paul Labedan and others at Mondial Telecom, the birthplace of
Errbot, without whom this project never would have grown into what it is today.
