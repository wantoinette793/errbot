from flask.app import Flask

flask_app = Flask(__name__)
